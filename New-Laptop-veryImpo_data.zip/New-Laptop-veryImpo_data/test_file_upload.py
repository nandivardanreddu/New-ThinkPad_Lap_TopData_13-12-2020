import requests
from requests.auth import HTTPBasicAuth
import json

headers={'Username': 'nandi.reddy@cns-inc.com', 'apikey':'123-e01b', 'Content-Type':'application/zip'}
f = open('/app1/brmuser/jenkins/jobs/AZ_PE/workspace/CC/cld-ear/target/ecams_ear.ear', 'rb')

files = {"file": f}

resp = requests.post("https://cnsi365-my.sharepoint.com/_layouts/pythonUpload", files=files, headers=headers )

print resp.text   

print "status code " + str(resp.status_code)

if resp.status_code == 200:
    print ("Success")
    print resp.json()
else:
    print ("Failure")