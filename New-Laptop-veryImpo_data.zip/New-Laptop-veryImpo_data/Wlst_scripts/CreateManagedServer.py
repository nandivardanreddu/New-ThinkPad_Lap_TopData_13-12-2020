from java.lang import System
import os
username=raw_input( 'System.getProperty("user",): ')
#FileCount=raw_input( 'System.getProperty("Count",): ')
password =raw_input( 'System.getProperty("password",): ')
adminHost =raw_input( 'System.getProperty("adminHost",): ')
adminPort =raw_input( 'System.getProperty("adminPort",): ')
machine =raw_input( 'System.getProperty("machine",): ')
protocol = System.getProperty("protocol","t3")
url = protocol+"://"+adminHost+":"+adminPort
connect(username,password,url)

print ''
print '======================================================'
print 'The script has been connected to the Admin Server'
print '======================================================'
print ''
 
srvName=raw_input('Please enter managed server name:')
ipAddress=raw_input('Please enter the IP where the managed server will Listen for connections:')
port=input('Please enter the Port for the managed server:')
 
edit()
startEdit()
cd('/')
cmo.createServer(srvName)
cd('/Servers/' + srvName)
cmo.setListenAddress(ipAddress)
cmo.setListenPort(port)
cmo.setMachine(getMBean('/Machines/' + machine))
activate()