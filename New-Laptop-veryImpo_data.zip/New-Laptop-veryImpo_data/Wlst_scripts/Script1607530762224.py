
cd('/')
cmo.createJDBCSystemResource('RuleITPRDS')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS')
cmo.setName('RuleITPRDS')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDataSourceParams/RuleITPRDS')
set('JNDINames',jarray.array([String('RuleITPRDS')], String))

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS')
cmo.setDatasourceType('GENERIC')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS')
cmo.setUrl('jdbc:oracle:thin:@//172.27.241.211:1521/utc3ecdv.ap-south-1.compute.internal:POOLED')
cmo.setDriverName('oracle.jdbc.OracleDriver')
setEncrypted('Password', 'Password_1607530892316', '/app1/cloudauto/weblogic12/wls12213/user_projects/domains/Automation_Domain/Script1607530762224Config', '/app1/cloudauto/weblogic12/wls12213/user_projects/domains/Automation_Domain/Script1607530762224Secret')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCConnectionPoolParams/RuleITPRDS')
cmo.setTestTableName('SQL ISVALID\r\n')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS')
cmo.createProperty('user')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/user')
cmo.setValue('PRDMMISISR')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS')
cmo.createProperty('oracle.jdbc.DRCPConnectionClass')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/oracle.jdbc.DRCPConnectionClass')
cmo.setValue('jdbc:oracle:thin:@//172.27.241.211:1521/utc3ecdv.ap-south-1.compute.internal')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDataSourceParams/RuleITPRDS')
cmo.setGlobalTransactionsProtocol('OnePhaseCommit')

cd('/JDBCSystemResources/RuleITPRDS')
set('Targets',jarray.array([ObjectName('com.bea:Name=AdminServer,Type=Server'), ObjectName('com.bea:Name=MS1,Type=Server'), ObjectName('com.bea:Name=MS2,Type=Server'), ObjectName('com.bea:Name=MS4,Type=Server')], ObjectName))

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/user')
cmo.unSet('SysPropValue')
cmo.unSet('EncryptedValue')
cmo.setValue('PRDMMISISR')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/oracle.jdbc.DRCPConnectionClass')
cmo.unSet('SysPropValue')
cmo.unSet('EncryptedValue')
cmo.setValue('jdbc:oracle:thin:@//172.27.241.211:1521/utc3ecdv.ap-south-1.compute.internal')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCConnectionPoolParams/RuleITPRDS')
cmo.setInactiveConnectionTimeoutSeconds(0)
cmo.setTestConnectionsOnReserve(false)
cmo.setWrapTypes(false)
cmo.setInitialCapacity(1)
cmo.setPinnedToThread(false)
cmo.setHighestNumWaiters(2147483647)
cmo.setCountOfRefreshFailuresTillDisable(2)
cmo.setStatementTimeout(-1)
cmo.setConnectionHarvestMaxCount(1)
cmo.setLoginDelaySeconds(0)
cmo.setMinCapacity(1)
cmo.setCountOfTestFailuresTillFlush(2)
cmo.setSecondsToTrustAnIdlePoolConnection(10)
cmo.setShrinkFrequencySeconds(900)
cmo.setConnectionHarvestTriggerCount(-1)
cmo.setConnectionReserveTimeoutSeconds(10)
cmo.setRemoveInfectedConnections(true)
cmo.setStatementCacheSize(10)
cmo.setTestTableName('SQL ISVALID\r\n')
cmo.setMaxCapacity(15)
cmo.setIgnoreInUseConnectionsEnabled(true)
cmo.setConnectionCreationRetryFrequencySeconds(0)
cmo.setTestFrequencySeconds(120)
cmo.setStatementCacheType('LRU')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS')
cmo.setUrl('jdbc:oracle:thin:@//172.27.241.211:1521/utc3ecdv.ap-south-1.compute.internal')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS')
cmo.destroyProperty(getMBean('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/oracle.jdbc.DRCPConnectionClass'))

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCDriverParams/RuleITPRDS/Properties/RuleITPRDS/Properties/user')
cmo.unSet('SysPropValue')
cmo.unSet('EncryptedValue')
cmo.setValue('PRDMMISISR')

cd('/JDBCSystemResources/RuleITPRDS/JDBCResource/RuleITPRDS/JDBCConnectionPoolParams/RuleITPRDS')
cmo.setTestTableName('SQL ISVALID\r\n')

activate()
