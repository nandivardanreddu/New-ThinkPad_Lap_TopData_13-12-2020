from java.lang import System
import os

JVM =raw_input( 'System.getProperty("Please enter JVM arguments",): ')
username=raw_input( 'System.getProperty("user",): ')
#FileCount=raw_input( 'System.getProperty("Count",): ')
password =raw_input( 'System.getProperty("password",): ')
adminHost =raw_input( 'System.getProperty("adminHost",): ')
adminPort =raw_input( 'System.getProperty("adminPort",): ')
protocol = System.getProperty("protocol","t3")
url = protocol+"://"+adminHost+":"+adminPort
connect(username,password,url)

srvName=raw_input('Please enter managed server name:')

edit()
startEdit()
cd('/')
cd('/Servers/' + srvName + '/ServerStart/' + srvName)
cmo.setArguments(JVM)

#cmo.setArguments('JVM')
#cmo.setMachine(getMBean('/Machines/' + machine))
activate()