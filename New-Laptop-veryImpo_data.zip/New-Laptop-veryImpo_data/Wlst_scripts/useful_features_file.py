
cd('/Servers/MS1/Log/MS1')
cmo.setFileCount(100)
cmo.setNumberOfFilesLimited(true)

activate()

startEdit()

activate()

startEdit()
cmo.setDateFormatPattern('d MMM, yyyy h:mm:ss,SSS a z')
cmo.setLogMonitoringMaxThrottleMessageSignatureCount(1000)
cmo.setRedirectStderrToServerLogEnabled(false)
cmo.setDomainLogBroadcasterBufferSize(1)
cmo.setRedirectStdoutToServerLogEnabled(false)
cmo.setStdoutLogStack(true)
cmo.setLogMonitoringIntervalSecs(30)
cmo.setLogMonitoringEnabled(true)
cmo.setStacktraceDepth(5)
cmo.setLoggerSeverity('Info')
cmo.setStdoutFormat('standard')
cmo.setLogMonitoringThrottleThreshold(1500)
cmo.setNumberOfFilesLimited(false)
cmo.setStdoutSeverity('Notice')
cmo.setLogMonitoringThrottleMessageLength(50)
cmo.setBufferSizeKB(8)
cmo.setDomainLogBroadcastSeverity('Notice')
cmo.setLogFileSeverity('Trace')

activate()

startEdit()

cd('/')
cmo.createServer('MS3')

cd('/Servers/MS3')
cmo.setListenAddress('10.86.25.21')
cmo.setListenPort(50030)

activate()

startEdit()
cmo.setListenPortEnabled(true)
cmo.setClientCertProxyEnabled(false)
cmo.setJavaCompiler('javac')
cmo.setMachine(getMBean('/Machines/Machine1'))
cmo.setCluster(None)

cd('/Servers/MS3/SSL/MS3')
cmo.setEnabled(false)

cd('/Servers/MS3/ServerDiagnosticConfig/MS3')
cmo.setWLDFDiagnosticVolume('Low')

activate()

startEdit()

cd('/Servers/MS3/Log/MS3')
cmo.setFileMinSize(10000)
cmo.setFileName('/app1/cloudauto/Logs/Weblogic_Domain/ManagedServers/AutoLogs/MS3/Log.log')
cmo.setRotationType('bySize')
cmo.setNumberOfFilesLimited(true)
cmo.setFileCount(100)
cmo.setNumberOfFilesLimited(false)
cmo.setRotateLogOnStartup(true)

activate()

startEdit()
