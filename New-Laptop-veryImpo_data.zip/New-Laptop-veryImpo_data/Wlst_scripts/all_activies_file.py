
startEdit()

cd('/Servers/MS1/Log/MS1')
cmo.setFileMinSize(10000)
cmo.setFileName('/app1/cloudauto/Logs/Weblogic_Domain/ManagedServers/AutoLogs/MS1.log')
cmo.setRotationType('bySize')
cmo.setNumberOfFilesLimited(false)
cmo.setRotateLogOnStartup(true)

activate()

startEdit()

activate()

startEdit()

cd('/')
cmo.createServer('MS2')

cd('/Servers/MS2')
cmo.setListenAddress('10.86.25.21')
cmo.setListenPort(50029)

activate()

startEdit()
cmo.setListenPortEnabled(true)
cmo.setClientCertProxyEnabled(false)
cmo.setJavaCompiler('javac')
cmo.setMachine(getMBean('/Machines/Machine1'))
cmo.setCluster(None)

cd('/Servers/MS2/SSL/MS2')
cmo.setEnabled(false)

cd('/Servers/MS2/ServerDiagnosticConfig/MS2')
cmo.setWLDFDiagnosticVolume('Low')

activate()

startEdit()

cd('/Servers/MS2/Log/MS2')
cmo.setFileMinSize(10000)
cmo.setFileName('Encrypted_log_path/srvName.log')
cmo.setRotationType('bySize')
cmo.setNumberOfFilesLimited(false)
cmo.setRotateLogOnStartup(true)

activate()

startEdit()
cmo.setFileMinSize(10000)

startEdit()
cmo.setFileMinSize(10000)
cmo.setFileName('/app1/cloudauto/Logs/Weblogic_Domain/ManagedServers/AutoLogs/MS2/Log.log')
cmo.setRotationType('bySize')
cmo.setNumberOfFilesLimited(false)
cmo.setRotateLogOnStartup(true)

activate()

startEdit()
