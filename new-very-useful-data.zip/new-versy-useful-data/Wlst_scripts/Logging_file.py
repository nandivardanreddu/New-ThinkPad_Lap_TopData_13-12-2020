from java.lang import System
import os

Encrypted_log_path =raw_input( 'System.getProperty("Please enter the encrypted log path",): ')
#RotationFileSize =raw_input( 'System.getProperty("Please enter rotation file size",): ')
#JVM =raw_input( 'System.getProperty("Please enter JVM arguments",): ')
username =raw_input( 'System.getProperty("user",): ')
password =raw_input( 'System.getProperty("password",): ')
adminHost =raw_input( 'System.getProperty("adminHost",): ')
adminPort =raw_input( 'System.getProperty("adminPort",): ')
protocol = System.getProperty("protocol","t3")
url = protocol+"://"+adminHost+":"+adminPort
connect(username,password,url)

srvName =raw_input('Please enter managed server name:')


edit()
startEdit()
cd('/')
cd('/Servers/' + srvName + '/Log/' + srvName)
#cd('/Servers/MS1/Log/MS1')
cmo.setFileMinSize(10000)
cmo.setFileName(Encrypted_log_path + '/Log.log')
cmo.setRotationType('bySize')
cmo.setNumberOfFilesLimited(true)
cmo.setFileCount(100)
cmo.setNumberOfFilesLimited(false)
cmo.setRotateLogOnStartup(true)

activate()

